-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: i10d105.p.ssafy.io    Database: anudar
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Exhibition`
--

DROP TABLE IF EXISTS `Exhibition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Exhibition` (
  `exhibition_id` bigint NOT NULL AUTO_INCREMENT,
  `detail` varchar(255) DEFAULT NULL,
  `end_time` datetime(6) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `start_time` datetime(6) DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`exhibition_id`),
  KEY `FKq9mur6k2lwsotqavafea4f4qv` (`user_id`),
  CONSTRAINT `FKq9mur6k2lwsotqavafea4f4qv` FOREIGN KEY (`user_id`) REFERENCES `User` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Exhibition`
--

LOCK TABLES `Exhibition` WRITE;
/*!40000 ALTER TABLE `Exhibition` DISABLE KEYS */;
INSERT INTO `Exhibition` VALUES (1,'계절에 따라 변해가는 풍경을 담아보았습니다.','2024-03-31 23:59:59.000000','https://anudar-img.s3.ap-northeast-2.amazonaws.com/exhibit/585e88a9-3cd7-4fec-9b9a-7c72b01f12ed.jpg','계절의 흐름','2024-03-01 00:00:00.000000',4),(2,'A curious herbal\nAuthor(s): Jeniffer Miller, Elizabeth Blackwell Publication Info: London, John Nourse, 1739','2024-03-31 23:59:59.000000','https://anudar-img.s3.ap-northeast-2.amazonaws.com/exhibit/d1bb1a49-07d3-49cd-9b0c-39aaf79c755e.jpg','A curious herbal','2024-03-01 00:00:00.000000',1),(3,'다양한 동물들을 담은 그림들을 모은 \'Animals\' 전시회 입니다. 이 전시회는 2008년부터 2023년까지 15년 동안 그린 그림들 중 선정된 그림들입니다. 자연과 함께하는 동물부터 사람들과 함께하는 동물까지 다양한 그림들을 즐겨주세요!','2024-03-31 23:59:59.000000','https://anudar-img.s3.ap-northeast-2.amazonaws.com/exhibit/cf1d87e9-da47-43d6-8ed6-452809d6d9f2.jpg','Animals','2024-02-15 00:00:00.000000',2),(4,'북쪽에서 불어온 바람, 그와 함께한 나의 유년','2024-03-31 23:59:59.000000','https://anudar-img.s3.ap-northeast-2.amazonaws.com/exhibit/27e2cdc2-a0a2-49e1-a96c-4016a39d2156.jpg','Youth','2024-03-01 00:00:00.000000',4),(6,'나의 마음은 무엇일까, 너의 마음 또한.','2024-03-31 23:59:59.000000','https://anudar-img.s3.ap-northeast-2.amazonaws.com/exhibit/eb6bb6d8-8b01-4486-afce-d862d0fc03c1.jpg','Mind','2024-02-15 00:00:00.000000',8),(9,'인간의 본질에 대해서 그려보았습니다.','2024-03-31 23:59:59.000000','https://anudar-img.s3.ap-northeast-2.amazonaws.com/exhibit/4ead5ced-e200-481c-9894-16665838f279.jpg','인간이란 무엇인가','2024-03-01 00:00:00.000000',7),(12,'새로운 만남의 기회','2024-03-31 23:59:59.000000','https://anudar-img.s3.ap-northeast-2.amazonaws.com/exhibit/8b813284-de1d-43a8-adfd-08890b8fe3d7.jpg','Travel','2024-03-01 00:00:00.000000',10),(13,'나의 정신 세계를 그림으로 표현해보겠습니다.','2024-03-31 23:59:59.000000','https://anudar-img.s3.ap-northeast-2.amazonaws.com/exhibit/2118677b-277c-4a71-8ba6-fd92ca5d9c03.jpg','나의 정신 세계','2024-03-01 00:00:00.000000',9),(14,'창의성과 상상력의 문을 열어 예술의 다양한 형태와 아름다움을 탐험하는 공간입니다. 이 전시회는 문을 여는 순간, 관람객들에게 예술의 문턱을 넘어 아름다운 세계로 초대합니다. 예술의 세계로 보다 깊이 들어가고자 하는 이들에게 새로운 시각과 감동을 선사하려 합니다.','2024-03-31 23:59:59.000000','https://anudar-img.s3.ap-northeast-2.amazonaws.com/exhibit/d74f793d-4691-49a1-9e35-35fe493fcb37.jpg','문을 열다 ; 아트의 세계로','2024-03-01 00:00:00.000000',6);
/*!40000 ALTER TABLE `Exhibition` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16  9:43:04
