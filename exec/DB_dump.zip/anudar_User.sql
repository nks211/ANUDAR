-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: i10d105.p.ssafy.io    Database: anudar
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `User` (
  `user_id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `role` enum('USER','AUTHOR','ADMIN') DEFAULT NULL,
  `userpoints` bigint DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `UK_cdd273rg61diywe30f4k0t5mo` (`nickname`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES (1,'2024-02-15 08:12:24','2024-02-15 15:40:30','0000@000.000','https://anudar-img.s3.ap-northeast-2.amazonaws.com/user/15d2b1b0-dac7-4412-9c06-501d3714caba.jpg','제니퍼','제니퍼','$2a$10$v9ym7/pB75pVaLjmWfz0d.9FsnZ5dBhCnlSXJq5WY73NGeFRCoDKu','010-0000-0000','AUTHOR',1969,'jeniffer0812'),(2,'2024-02-15 08:13:15','2024-02-15 15:39:56','shonee99@naver.com','https://anudar-img.s3.ap-northeast-2.amazonaws.com/user/59df811b-f89b-4f85-95c3-ad5a741691a2.jpg','현수연','수연','$2a$10$BLxlgS8uIBL7uc3LDV64FeznrtmITGA8jY66Uuzt558znj7Uyc7Xy','010-7330-4353','AUTHOR',2046,'suyeon'),(4,'2024-02-15 08:23:14','2024-02-15 09:39:10','sgvina@naver.com','https://anudar-img.s3.ap-northeast-2.amazonaws.com/user/fff13147-b9e3-4d0d-9fa5-de774b6c73a0.jpg','안유나','유나','$2a$10$ig5NTt5wykKQkAXZG5swiewm3gF.Gftsy3e6lpPpWFAnXpT2DjdUe','010-9209-1693','AUTHOR',2000,'ahn'),(5,'2024-02-15 08:23:39','2024-02-15 08:23:39','admin@test.com','https://anudar-img.s3.ap-northeast-2.amazonaws.com/user/3ee66e98-3ded-408e-a13c-399d6b340772.jpg','admin','admin','$2a$10$RJ8ezWr0rz4mesWi1rBTRePP1pVd9WsPdNJSVd/bcORbmdYLWdaaK','010-1234-5678','USER',2000,'admin'),(6,'2024-02-15 08:31:49','2024-02-15 15:37:37','gyuri@ssafy.com','https://anudar-img.s3.ap-northeast-2.amazonaws.com/user/7113dd62-8100-4a3a-b21a-89033cc6cfc1.jpg','박규리','규리','$2a$10$G6mzus/CS5q7tv/T.IeexugBquOJ6Dy8Bx91V9Ctgokqd7u1VZKRm','010-0000-0000','AUTHOR',2000,'gyuri'),(7,'2024-02-15 08:59:01','2024-02-15 10:37:59','hh123@test.com','https://anudar-img.s3.ap-northeast-2.amazonaws.com/user/f9edf55e-0fb0-4175-a3a8-24c4f306b6e3.jpg','김홍희','김홍희','$2a$10$rQvM3DREhP3ClRw8ixsZsOWbHYpBIK1fzS8J.pKBCTW1ntLIfGTj6','010-1234-5678','AUTHOR',2100,'ssafy'),(8,'2024-02-15 09:07:28','2024-02-15 09:35:15','mini@ssafy.com','https://anudar-img.s3.ap-northeast-2.amazonaws.com/user/6154c55c-60ff-4049-b1c2-a08c6729cc21.jpg','민희','민희','$2a$10$SvDudkvvj1RwJqSxQz89beYircjKb9nkcy1Tx6i/yTHLkrhlUAKwu','010-1234-5678','AUTHOR',2000,'mini'),(9,'2024-02-15 09:35:04','2024-02-15 09:55:30','admin@test.com','https://anudar-img.s3.ap-northeast-2.amazonaws.com/user/7866fcba-9d4b-4df7-95e0-ddd770cb51c4.jpg','김은희','김은희','$2a$10$f260EbwC01sfBmgf8Lsz7eiPy0UMxiytQYIVsjeD1e2p.7OCX35KC','010-1234-5678','AUTHOR',2000,'ssafy1'),(10,'2024-02-15 09:42:22','2024-02-15 10:42:11','sayho@ssafy.com','https://anudar-img.s3.ap-northeast-2.amazonaws.com/user/effde2b5-8b14-4f11-b412-0a91198d5d29.jpg','이헤호','헤호','$2a$10$qmPwT/mMw3BNe9eyXXQAU.YyW5Xjry4c9zUskucHF1kGWUm5BCh16','010-9987-6543','AUTHOR',1674,'sayho');
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16  9:43:02
